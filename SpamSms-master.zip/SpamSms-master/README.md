# SpamSms

Kumpulan Beberapa Script Spam Sms Buatan Para Mastah.

Saya Hanya Bantu Nyusun Agar Lebih Mudah Di Gunakan Saja.

Sebelum Menjalankan Spam AllCall
Masukkan Nomer2 Yang Mau Di SpamCall
Ke Dalam File No.txt Bisa di edit pake nano no.txt
Atau lewat file manager Pake apk buat edit file no.txt nya
